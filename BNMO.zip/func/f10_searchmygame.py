from .functions import*
from .f09_listgame import*

def search_my_game(game,kepemilikan,user_id):
    id = input("Masukkan ID Game: ")
    tahun_rilis = input("Masukkan Tahun Rilis Game: ")
    found = False
    temp = []
    tempo  = []
    tempor = []
    count = 0

    for i in range(length(kepemilikan)):
        if user_id == kepemilikan[i][1]:
            temp += [kepemilikan[i][0]]

    for i in range(length(game)):
        for j in range(length(temp)):
            if temp[j] == game[i][0]:
                    tempo += [[game[i][0],game[i][1],game[i][4],game[i][2],game[i][3]]]

    if id == '' and tahun_rilis == '':
        found = True
        for i in range(length(tempo)):
            tempor += [[tempo[i][0],tempo[i][1],tempo[i][2],tempo[i][3],tempo[i][4]]]
    else:
        for i in range(length(tempo)):
            if id == tempo[i][0]:
                count += 1
                found = True
                tempor += [[tempo[i][0],tempo[i][1],tempo[i][2],tempo[i][3],tempo[i][4]]]
            elif tahun_rilis == tempo[i][4]:
                count += 1
                found = True
                tempor += [[tempo[i][0],tempo[i][1],tempo[i][2],tempo[i][3],tempo[i][4]]]

    print("Daftar game pada inventory yang memenuhi kriteria:")
    if found == False or (found == True and count > 1):
        print('Tidak ada game pada inventory-mu yang memenuhi kriteria.')
    else:
        for i in range(length(tempor[0])):
            spaces(tempor,i)
        num = [0 for i in range(length(tempor))]
        for i in range(length(num)):
            num[i] = i+1
        numSpaces(num)
        for i in range(length(tempor)):
            print(str(num[i]) + ' ' + tempor[i][0] + ' | ' + tempor[i][1] + ' | ' + tempor[i][2] + ' | ' + tempor[i][3] + ' | ' + tempor[i][4])
        