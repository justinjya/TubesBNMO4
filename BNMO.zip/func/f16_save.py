from .functions import*

def save(user,game,kepemilikan,history):
    user = arraytocsv(user)
    game = arraytocsv(game)
    kepemilikan = arraytocsv(kepemilikan)
    history = arraytocsv(history)
    
    dir = './'
    os.chdir(dir)
    folder = input('Masukan nama folder penyimpanan: ')
    
    if not os.path.exists('saves/' + folder):
        os.mkdir('saves/' + folder)

    f = open('saves/' + str(folder) + '/user.csv','w')
    f.write('id;username;nama;password;role;saldo\n')
    f.writelines(user)
    f.close
    f = open('saves/' + str(folder) + '/game.csv','w')
    f.write('id;nama;kategori;tahun_rilis;harga;stok\n')
    f.writelines(game)
    f.close
    f = open('saves/' + str(folder) + '/kepemilikan.csv','w')
    f.write('game_id;user_id\n')
    f.writelines(kepemilikan)
    f.close
    f = open('saves/' + str(folder) + '/riwayat.csv','w')
    f.write('game_id;nama;harga;user_id;tahun_beli\n')
    f.writelines(history)
    f.close

    print('Saving...')
    print('Data telah tersimpan pada folder',folder)