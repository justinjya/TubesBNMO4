from .functions import*

def topup(user):
    username = input('Masukkan username: ')
    tambah = int(input('Masukkan saldo: '))

    for i in range(length(user)):
        if username == user[i][1]:
            if tambah < 0 and abs(tambah) > int(user[i][5]):
                print('Masukan tidak valid')
            else:
                user[i][5] = str(int(user[i][5]) + tambah)
                if tambah > 0:
                    print('Top up berhasil. Saldo', user[i][2], 'bertambah menjadi', user[i][5])
                else:
                    print('Pengurangan berhasil. Saldo', user[i][2], 'berkurang menjadi', user[i][5])
            break
    else:
        print('Username', username, 'tidak ditemukan,')