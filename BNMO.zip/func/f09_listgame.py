from .functions import*

def list_game(game,kepemilikan,user_id):
    count = 0
    temp = []
    tempo = []

    for i in range(length(kepemilikan)):
        if user_id == kepemilikan[i][1]:
            count += 1
            temp += [kepemilikan[i][0]]
    
    for i in range(length(game)):
        for j in range(length(temp)):
            if temp[j] == game[i][0]:
                tempo += [[game[i][0],game[i][1],game[i][2],game[i][3],game[i][4]]]
    
    print('Daftar game:')
    if count == 0:
        print('Maaf, kamu belum memiliki game. Ketik perintah "buy_game" untuk beli.')
    else:
        for i in range(length(tempo[0])):
            spaces(tempo,i)
        num = [0 for i in range(length(tempo))]
        for i in range(length(num)):
            num[i] = i+1
        numSpaces(num)
        for i in range(length(tempo)):
            print(str(num[i]) + ' ' + tempo[i][0] + ' | ' + tempo[i][1] + ' | ' + tempo[i][2] + ' | ' + tempo[i][3] + ' | ' + tempo[i][4])
