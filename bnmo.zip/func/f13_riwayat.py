from re import L
from .functions import*

def riwayat(history,user_id):
    temp = []
    for i in range(length(history)):
        if user_id == history[i][3]:
            temp += [[history[i][0],history[i][1],history[i][2],history[i][4]]]

    if length(temp) == 0:
        print('Maaf, kamu tidak ada riwayat pembelian game. Ketik perintah "buy_game" untuk membeli.')
    else:
        for i in range(length(temp[0])):
            spaces(temp,i)
        num = [0 for i in range(length(temp))]
        for i in range(length(num)):
            num[i] = i+1
        numSpaces(num)
        print('Daftar game:')
        for i in range(length(temp)):
            print(str(num[i]) + ' ' + temp[i][0] + ' | ' + temp[i][1] + ' | ' + temp[i][2] + ' | ' + temp[i][3])