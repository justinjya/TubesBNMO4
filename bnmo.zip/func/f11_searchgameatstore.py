from .functions import*

def search_game_at_store(game):
    id = input('Masukkan ID Game: ')
    nama = input('Masukkan Nama Game: ')
    harga = str(input('Masukkan Harga Game: '))
    kategori = str(input('Masukkan Kategori Game: '))
    tahun_rilis = str(input('Masukkan Tahun Rilis Game: '))
    temp = []
    found = False
    count = 0

    if id == '' and nama == '' and harga == '' and kategori == '' and tahun_rilis == '':
        found = True
        for i in range(length(game)):
            temp += [[game[i][0],game[i][1],game[i][4],game[i][2],game[i][3],game[i][5]]]
    else:
        for i in range(length(game)):
            if id == game[i][0]:
                count += 1
                found = True
                temp += [[id,game[i][1],game[i][4],game[i][2],game[i][3],game[i][5]]]
            elif nama == game[i][1]:
                count += 1
                found = True
                temp += [[game[i][0],nama,game[i][4],game[i][2],game[i][3],game[i][5]]]
            elif harga == game[i][4]:
                count += 1
                found = True
                temp += [[game[i][0],game[i][1],harga,game[i][2],game[i][3],game[i][5]]]
            elif kategori == game[i][2]:
                count += 1
                found = True
                temp += [[game[i][0],game[i][1],game[i][4],kategori,game[i][3],game[i][5]]]
            elif tahun_rilis == game[i][3]:
                count += 1
                found = True
                temp += [[game[i][0],game[i][1],game[i][4],game[i][2],tahun_rilis,game[i][5]]]

    print("Daftar game pada toko yang memenuhi kriteria:")
    if found == False or (found == True and count > 1):
        print('Tidak ada game yang memenuhi kriteria.')
    else:
        for i in range(length(temp[0])):
            spaces(temp,i)
        num = [0 for i in range(length(temp))]
        for i in range(length(num)):
            num[i] = i+1
        numSpaces(num)
        for i in range(length(temp)):
            print(str(num[i]) + ' ' + temp[i][0] + ' | ' + temp[i][1] + ' | ' + temp[i][2] + ' | ' + temp[i][3] + ' | ' + temp[i][4] + ' | ' + temp[i][5])
