from .f16_save import save

def exit(user,game,kepemilikan,history):
    inpt = input('Apakah Anda mau melakukan penyimpanan file yang sudah diubah? (y/n) ')

    if inpt == 'Y' or inpt == 'y':
        save(user,game,kepemilikan,history)
        return
    elif inpt == 'N' or inpt == 'n':
        return