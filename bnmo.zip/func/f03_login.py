from .functions import*
from .b01_cipher import cipher

def login(user):
    username_login = input('Masukkan username: ')
    password_login = input('Masukkan password: ')

    temp = cipher(password_login)
    for i in range(length(user)):
        if username_login == user[i][1] and temp == user[i][3]:
            print('Halo ' + user[i][2] + '! Selamat datang di "Binomo".')
            logged = True
            user_id = user[i][0]
            role = user[i][4]
            return logged, user_id, role
    else:
        logged = False
        user_id = ''
        role = ''
        print('Password atau username salah atau tidak ditemukan.') 
        return logged, user_id, role