from .functions import*

def buy_game(user,game,kepemilikan,history,user_id):
    id = input('Masukkan ID game: ')
    count = 0

    for i in range(length(kepemilikan)):
        count += 1
        if id == kepemilikan[i][0] and user_id == kepemilikan[i][1]:
            print('Anda sudah memiliki game tersebut!')
            return
    if count == length(kepemilikan):
        for i in range(length(game)):
            if id == game[i][0]:
                if int(game[i][5]) > 0:                
                    if int(user[int(user_id)-1][5]) >= int(game[i][4]):
                        temp = [game[i][0],user_id]
                        today = str(datetime.today().year)
                        tempo = [game[i][0],game[i][1],game[i][4],user_id,today]
                        user[int(user_id)-1][5] = str(int(user[int(user_id)-1][5]) - int(game[i][4]))
                        game[i][5] = str(int(game[i][5]) - 1)
                        kepemilikan += [temp]
                        history += [tempo]
                        print('Game',game[i][1],'berhasil dibeli!')
                        break
                    else:
                        print('Saldo anda tidak cukup untuk membeli game tersebut!')
                        break
                else:
                    print('Stok game tersebut sedang habis!')
                    break