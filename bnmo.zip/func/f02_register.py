from .functions import*
from .b01_cipher import cipher

def register(user):
    nama = input('Masukkan nama: ')
    username = input('Masukkan username: ')
    password = input('Masukkan password: ')

    for i in range(length(user)):
        if username == user[i][1]:
            print('Username', username, 'sudah terpakai, silahkan menggunakan username lain')
            break
    else:
        count = 0
        temp = []
        for i in range(length(username)):
            temp += [ord(username[i])]
        for i in range(length(username)):
            if length(username) < 5:
                print('Username harus memiliki minimal 5 karakter')
                break
            else:
                for i in range(length(username)):
                    if (temp[i] >= 97 and temp[i] <= 122) or (temp[i] >= 65 and temp[i] <= 90) or (temp[i] >= 48 and temp[i] <= 57) or (temp[i] == 45) or (temp[i] == 95):
                        count += 1
                if count == length(username):
                    print('Username', username, 'telah berhasil register ke dalam "Binomo".')
                    temp = [length(user)+1, username, nama, cipher(password), 'user', 0]
                    user += [temp]
                    break
                else:
                    print('Username hanya dapat mengandung huruf besar, huruf kecil, angka 0-9, underscore "_", dan strip "_"')
                    break