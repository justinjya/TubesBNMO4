from .functions import*

def tambah_game(game):
    nama = input('Masukkan nama game: ')
    kategori = input('Masukkan kategori: ')
    tahun_rilis = input('Masukkan tahun rilis: ')
    harga = input('Masukkan harga: ')
    stok = input('Masukkan stok awal: ')

    while nama == '' or kategori == '' or tahun_rilis == '' or harga == '' or stok == '':
        print('Mohon masukkan semua informasi mengenai game agar dapat disimpan BNMO.')
        nama = input('Masukkan nama game: ')
        kategori = input('Masukkan kategori: ')
        tahun_rilis = input('Masukkan tahun rilis: ')
        harga = input('Masukkan harga: ')
        stok = input('Masukkan stok awal: ')
    else:
        print('Selamat! Berhasil menambahkan game', nama)
        temp = ['G'+str(int(length(game))+1), nama, kategori, str(tahun_rilis), str(harga), str(stok)]
        game += [temp]