from .functions import*

def ubah_game(game):
    id = input('Masukkan ID game: ')
    nama = input('Masukkan nama game: ')
    kategori = input('Masukkan kategori: ')
    tahun_rilis = input('Masukkan tahun rilis: ')
    harga = input('Masukkan harga: ')

    for i in range(length(game)):
        if id == game[i][0]:
            if nama != '':
                game[i][1] = nama
            if kategori != '':
                game[i][2] = kategori
            if tahun_rilis != '':
                game[i][3] = str(tahun_rilis)
            if harga != '':
                game[i][4] = str(harga)